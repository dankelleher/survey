(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.create = create;
	exports.get = get;

	var _database = __webpack_require__(1);

	var _database2 = _interopRequireDefault(_database);

	var _createSurvey = __webpack_require__(3);

	var _getSurvey = __webpack_require__(9);

	var _lambdaIO = __webpack_require__(11);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var client = (0, _database2.default)();

	function create(event, context, callback) {
	  // return control to process handler after callback is called
	  // allows db connection pool to stay open
	  context.callbackWaitsForEmptyEventLoop = false;

	  var entity = (0, _lambdaIO.parseBody)(event);

	  try {
	    (0, _createSurvey.create)(client(), entity.name, entity.elements).then(function (generatedId) {
	      return callback(null, (0, _lambdaIO.creationResponse)(generatedId));
	    }, callback);
	  } catch (e) {
	    console.log(e);
	    callback(e);
	  }
	}

	function get(event, context, callback) {
	  // return control to process handler after callback is called
	  // allows db connection pool to stay open
	  context.callbackWaitsForEmptyEventLoop = false;

	  console.log(event);

	  try {
	    (0, _getSurvey.get)(client(), event.pathParameters.id).then(function (survey) {
	      return callback(null, (0, _lambdaIO.getResponse)(survey));
	    }, callback);
	  } catch (e) {
	    console.log(e);
	    callback(e);
	  }
	}

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports.default = function (config) {
	  var client = new pg.Client(config);
	  var connected = false;

	  // return a getter function for the client. Connect if not connected
	  return function () {
	    if (!connected) {
	      connected = true;

	      // connect to the database - once per client - happens once per lambda container
	      client.connect();
	    }

	    return client;
	  };
	};

	var pg = __webpack_require__(2);

	;

/***/ },
/* 2 */
/***/ function(module, exports) {

	module.exports = require("pg");

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.create = undefined;

	var _regenerator = __webpack_require__(4);

	var _regenerator2 = _interopRequireDefault(_regenerator);

	var _promise = __webpack_require__(5);

	var _promise2 = _interopRequireDefault(_promise);

	var _asyncToGenerator2 = __webpack_require__(6);

	var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

	var create = exports.create = function () {
	  var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(client, surveyName) {
	    var elements = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
	    var creationResult, surveyId, addElementToSurvey;
	    return _regenerator2.default.wrap(function _callee$(_context) {
	      while (1) {
	        switch (_context.prev = _context.next) {
	          case 0:
	            _context.next = 2;
	            return client.query('INSERT INTO survey VALUES (DEFAULT, $1::text) RETURNING id;', [surveyName]).catch(queryError);

	          case 2:
	            creationResult = _context.sent;
	            surveyId = extractGeneratedId(creationResult);
	            addElementToSurvey = _ramda2.default.curry(_createElement.create)(client, surveyId);
	            _context.next = 7;
	            return _promise2.default.all(elements.map(addElementToSurvey)).catch(queryError);

	          case 7:
	            return _context.abrupt('return', surveyId);

	          case 8:
	          case 'end':
	            return _context.stop();
	        }
	      }
	    }, _callee, this);
	  }));

	  return function create(_x, _x2) {
	    return _ref.apply(this, arguments);
	  };
	}();

	var _ramda = __webpack_require__(7);

	var _ramda2 = _interopRequireDefault(_ramda);

	var _createElement = __webpack_require__(8);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function queryError(error) {
	  throw error;
	}

	var extractGeneratedId = function extractGeneratedId(result) {
	  return result.rows[0].id;
	};

/***/ },
/* 4 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/regenerator");

/***/ },
/* 5 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/core-js/promise");

/***/ },
/* 6 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ },
/* 7 */
/***/ function(module, exports) {

	module.exports = require("ramda");

/***/ },
/* 8 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.create = create;
	function queryError(error) {
	  throw error;
	}

	var extractGeneratedId = function extractGeneratedId(result) {
	  return result.rows[0].id;
	};

	function create(client, surveyId, elementName) {
	  return client.query('INSERT INTO survey_element VALUES (DEFAULT, $1::integer, $2::text) RETURNING id;', [surveyId, elementName]).then(extractGeneratedId, queryError);
	}

/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.get = undefined;

	var _regenerator = __webpack_require__(4);

	var _regenerator2 = _interopRequireDefault(_regenerator);

	var _promise = __webpack_require__(5);

	var _promise2 = _interopRequireDefault(_promise);

	var _slicedToArray2 = __webpack_require__(10);

	var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

	var _asyncToGenerator2 = __webpack_require__(6);

	var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

	var get = exports.get = function () {
	  var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(client, surveyId) {
	    var surveyNamePr, elementsPr, _ref2, _ref3, name, elements;

	    return _regenerator2.default.wrap(function _callee$(_context) {
	      while (1) {
	        switch (_context.prev = _context.next) {
	          case 0:
	            surveyNamePr = client.query('SELECT name FROM survey WHERE id = $1::integer', [surveyId]).then(firstRowName, queryError);
	            elementsPr = client.query('SELECT name FROM survey_element WHERE survey_id = $1::integer', [surveyId]).then(rowNames, queryError);
	            _context.next = 4;
	            return _promise2.default.all([surveyNamePr, elementsPr]);

	          case 4:
	            _ref2 = _context.sent;
	            _ref3 = (0, _slicedToArray3.default)(_ref2, 2);
	            name = _ref3[0];
	            elements = _ref3[1];
	            return _context.abrupt('return', {
	              name: name,
	              elements: elements
	            });

	          case 9:
	          case 'end':
	            return _context.stop();
	        }
	      }
	    }, _callee, this);
	  }));

	  return function get(_x, _x2) {
	    return _ref.apply(this, arguments);
	  };
	}();

	var _ramda = __webpack_require__(7);

	var _ramda2 = _interopRequireDefault(_ramda);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function queryError(error) {
	  throw error;
	}

	var rows = _ramda2.default.prop('rows');
	var names = _ramda2.default.pluck('name');
	var rowNames = _ramda2.default.compose(names, rows);
	var firstRowName = _ramda2.default.compose(_ramda2.default.head, rowNames);

/***/ },
/* 10 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/helpers/slicedToArray");

/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _stringify = __webpack_require__(12);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _extends2 = __webpack_require__(13);

	var _extends3 = _interopRequireDefault(_extends2);

	exports.creationResponse = creationResponse;
	exports.getResponse = getResponse;
	exports.throwOnError = throwOnError;
	exports.parseBody = parseBody;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/**
	 * Created by daniel on 20/02/2017.
	 *
	 * Helper functions to handle IO with AWS Lambda
	 */

	function creationResponse(generatedId) {
	  return (0, _extends3.default)({}, successfulResponse(), {
	    body: (0, _stringify2.default)({
	      message: 'Created successfully',
	      id: generatedId
	    })
	  });
	}

	function getResponse(entity) {
	  return (0, _extends3.default)({}, successfulResponse(), {
	    body: (0, _stringify2.default)(entity)
	  });
	}

	function throwOnError(err) {
	  throw err;
	}

	function parseBody(event) {
	  return JSON.parse(event.body);
	}

	function successfulResponse() {
	  return {
	    statusCode: 200,
	    headers: {
	      "Access-Control-Allow-Origin": "*" // Required for CORS support to work
	    }
	  };
	}

/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/core-js/json/stringify");

/***/ },
/* 13 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/helpers/extends");

/***/ }
/******/ ])));