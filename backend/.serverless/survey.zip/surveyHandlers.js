(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _stringify = __webpack_require__(1);

	var _stringify2 = _interopRequireDefault(_stringify);

	exports.create = create;

	var _database = __webpack_require__(2);

	var _database2 = _interopRequireDefault(_database);

	var _addSurvey = __webpack_require__(4);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var client = (0, _database2.default)();

	function create(event, context, callback) {
	  // return control to process handler after callback is called
	  // allows db connection pool to stay open
	  context.callbackWaitsForEmptyEventLoop = false;

	  var response = {
	    statusCode: 200,
	    body: (0, _stringify2.default)({
	      message: 'Created successfully',
	      input: event
	    })
	  };

	  try {
	    (0, _addSurvey.create)(client(), 'hamilton', function () {
	      return callback(null, response);
	    });
	  } catch (e) {
	    console.log(e);
	    callback(e);
	  }
	}

/***/ },
/* 1 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/core-js/json/stringify");

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports.default = function (config) {
	  var client = new pg.Client(config);
	  var connected = false;

	  // return a getter function for the client. Connect if not connected
	  return function () {
	    if (!connected) {
	      connected = true;

	      // connect to the database - once per client - happens once per lambda container
	      client.connect();
	    }

	    return client;
	  };
	};

	var pg = __webpack_require__(3);

	;

/***/ },
/* 3 */
/***/ function(module, exports) {

	module.exports = require("pg");

/***/ },
/* 4 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.create = create;
	function queryError(error) {
	  throw error;
	}

	function create(client, surveyName, callback) {

	  return client.query('INSERT INTO survey VALUES (DEFAULT, $1::text)', [surveyName]).then(callback, queryError);
	}

/***/ }
/******/ ])));