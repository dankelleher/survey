/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.create = create;

	var _database = __webpack_require__(1);

	var _database2 = _interopRequireDefault(_database);

	var _createResponse = __webpack_require__(13);

	var _lambdaIO = __webpack_require__(11);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var client = (0, _database2.default)();
	//import { get as getAverageResponse} from './getAverageResponse';
	function create(event, context, callback) {
	  // return control to process handler after callback is called
	  // allows db connection pool to stay open
	  context.callbackWaitsForEmptyEventLoop = false;

	  var entity = parseBody(event);

	  try {
	    (0, _createResponse.create)(client(), event.pathParameters.id, entity.elements).then(function (generatedId) {
	      return callback(null, (0, _lambdaIO.creationResponse)(generatedId));
	    }, callback);
	  } catch (e) {
	    console.log(e);
	    callback(e);
	  }
	}

	// export function get(event, context, callback) {
	//   // return control to process handler after callback is called
	//   // allows db connection pool to stay open
	//   context.callbackWaitsForEmptyEventLoop = false;
	//
	//   try {
	//     getSurvey(client(), event.pathParameters.id)
	//       .then((survey) => callback(null, getResponse(survey)));
	//   } catch (e) {
	//     console.log(e);
	//     callback(e);
	//   }
	// }

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports.default = function (config) {
	  var client = new pg.Client(config);
	  var connected = false;

	  // return a getter function for the client. Connect if not connected
	  return function () {
	    if (!connected) {
	      connected = true;

	      // connect to the database - once per client - happens once per lambda container
	      client.connect();
	    }

	    return client;
	  };
	};

	var pg = __webpack_require__(2);

	;

/***/ },
/* 2 */
/***/ function(module, exports) {

	module.exports = require("pg");

/***/ },
/* 3 */,
/* 4 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/regenerator");

/***/ },
/* 5 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/core-js/promise");

/***/ },
/* 6 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ },
/* 7 */
/***/ function(module, exports) {

	module.exports = require("ramda");

/***/ },
/* 8 */,
/* 9 */,
/* 10 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/helpers/slicedToArray");

/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _stringify = __webpack_require__(12);

	var _stringify2 = _interopRequireDefault(_stringify);

	exports.creationResponse = creationResponse;
	exports.getResponse = getResponse;
	exports.throwOnError = throwOnError;
	exports.parseBody = parseBody;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/**
	 * Created by daniel on 20/02/2017.
	 *
	 * Helper functions to handle IO with AWS Lambda
	 */

	function creationResponse(generatedId) {
	  return {
	    statusCode: 200,
	    body: (0, _stringify2.default)({
	      message: 'Created successfully',
	      id: generatedId
	    })
	  };
	}

	function getResponse(entity) {
	  return {
	    statusCode: 200,
	    body: (0, _stringify2.default)(entity)
	  };
	}

	function throwOnError(err) {
	  throw err;
	}

	function parseBody(event) {
	  return JSON.parse(event.body);
	}

/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = require("babel-runtime/core-js/json/stringify");

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.create = undefined;

	var _regenerator = __webpack_require__(4);

	var _regenerator2 = _interopRequireDefault(_regenerator);

	var _promise = __webpack_require__(5);

	var _promise2 = _interopRequireDefault(_promise);

	var _slicedToArray2 = __webpack_require__(10);

	var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

	var _asyncToGenerator2 = __webpack_require__(6);

	var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

	var create = exports.create = function () {
	  var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(client, surveyId, elementArray) {
	    var surveyElementsMap, responseId, idRankPairs, allInsertPromises;
	    return _regenerator2.default.wrap(function _callee$(_context) {
	      while (1) {
	        switch (_context.prev = _context.next) {
	          case 0:
	            _context.next = 2;
	            return getSurveyElementsPromise(client, surveyId);

	          case 2:
	            surveyElementsMap = _context.sent;

	            if (!(objectSize(surveyElementsMap) > elementArray.length)) {
	              _context.next = 5;
	              break;
	            }

	            throw new Error("Missing elements from response");

	          case 5:
	            _context.next = 7;
	            return getNextResponseId(client);

	          case 7:
	            responseId = _context.sent;
	            idRankPairs = elementArray.map(function (element, rank) {
	              return [surveyElementsMap[element], rank];
	            });
	            allInsertPromises = idRankPairs.map(function (_ref2) {
	              var _ref3 = (0, _slicedToArray3.default)(_ref2, 2),
	                  elementId = _ref3[0],
	                  rank = _ref3[1];

	              return responseInsertPromise(client, responseId, elementId, rank);
	            });
	            _context.next = 12;
	            return _promise2.default.all(allInsertPromises);

	          case 12:
	            return _context.abrupt('return', responseId);

	          case 13:
	          case 'end':
	            return _context.stop();
	        }
	      }
	    }, _callee, this);
	  }));

	  return function create(_x, _x2, _x3) {
	    return _ref.apply(this, arguments);
	  };
	}();

	var _ramda = __webpack_require__(7);

	var _ramda2 = _interopRequireDefault(_ramda);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var rows = _ramda2.default.prop('rows');
	var nameAndId = _ramda2.default.props(['name', 'id']);
	var nameAndIdPairs = _ramda2.default.map(nameAndId);
	var mapNameToId = _ramda2.default.compose(_ramda2.default.fromPairs, nameAndIdPairs, rows);

	var newResponseId = _ramda2.default.prop('new_id');
	var firstRowNewResponseId = _ramda2.default.compose(newResponseId, _ramda2.default.head, rows);
	var objectSize = _ramda2.default.compose(_ramda2.default.length, _ramda2.default.keys);

	function queryError(error) {
	  throw error;
	}

	function responseInsertPromise(client, responseId, surveyElementId, rank) {
	  return client.query('INSERT INTO survey_response VALUES ($1::integer, $2::integer, $3::integer);', [responseId, surveyElementId, rank]).catch(queryError);
	}

	function getSurveyElementsPromise(client, surveyId) {
	  return client.query('SELECT * FROM survey_element WHERE survey_id = $1::integer', [surveyId]).then(mapNameToId, queryError);
	}

	function getNextResponseId(client) {
	  return client.query('SELECT NEXTVAL(pg_get_serial_sequence(\'survey_response\', \'response_id\')) as new_id').then(firstRowNewResponseId, queryError);
	}

/***/ }
/******/ ]);